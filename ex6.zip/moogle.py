import crawl
import page_rank
import words_dict
import search
import sys


def main():
    if sys.argv[1] == "crawl":
        if len(sys.argv) == 5:
            # save all parameters
            base_url = sys.argv[2]
            index_file = sys.argv[3]
            out_file = sys.argv[4]
            dict1 = crawl.count_all_reference(index_file, base_url)
            crawl.save_dict(out_file, dict1)
        else:
            print("Error: please enter all variables")
    # python moogle.py crawl https://www.cs.huji.ac.il/~intro2cs1/ex6/wiki/ small_index.txt traffic.pickle
    elif sys.argv[1] == "page_rank":
        if len(sys.argv) == 5:
            # save all parameters
            iterations = int(sys.argv[2])
            dict_file = sys.argv[3]
            out_file = sys.argv[4]
            page_rank.page_rank(iterations, dict_file, out_file)
            # python moogle.py page_rank 100 traffic.pickle rank.pickle
        else:
            print("Error: please enter all variables")
    elif sys.argv[1] == "words_dict":
        if len(sys.argv) == 5:
            # save all parameters
            base_url = sys.argv[2]
            index_file = sys.argv[3]
            out_file = sys.argv[4]
            words_dict.words_dict(base_url, index_file, out_file)
            # python moogle.py words_dict https://www.cs.huji.ac.il/~intro2cs1/ex6/wiki/ small_index.txt words.pickle
        else:
            print("Error: please enter all variables")
    elif sys.argv[1] == 'search':
        if len(sys.argv) == 6:
            # save all parameters
            query = sys.argv[2]
            ranking_dict_file = sys.argv[3]
            words_dict_file = sys.argv[4]
            max_results = int(sys.argv[5])
            search.search(query, words_dict_file, ranking_dict_file,
                          max_results)
        # python moogle.py search < QUERY > < RANKING_DICT_FILE > < WORDS_DICT_FILE > < MAX_RESULTS >
        # python moogle.py search "scar" rank.pickle words.pickle 4


if __name__ == '__main__':
    main()
